package farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Activites;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Model.AppVersionResponse;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.R;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Support.RootActivity;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Support.SavedData;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.webservices.RetrofitApiClient;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Prince on 01-09-2017.
 */

public class LoginActivity extends RootActivity {

    private Context mContext;

    // list of permissions
    public static final int REQUEST_READ_PHONE_STATE = 22;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    Button btn_login;
    EditText edt_user_name, edt_password;
    ProgressDialog prg;
    Spinner spinner_Language;
    //String[] arr_language;
    ArrayAdapter spinner_key_adapter;
    List<AppVersionResponse.ListData> ListData;
    Intent locationService;
    boolean isClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ListData = new ArrayList<>();
        mContext = LoginActivity.this;


        //checkPermission();
        prg = new ProgressDialog(this);
        createids();
        // setLanguageSpinner();
        click_evnet();

    }


    private void click_evnet() {
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mContext, DashBoardActivity.class);
                startActivity(i);
                //checkValidation();

            }
        });


    }

    private void checkValidation() {
        Log.e("I m here...", "i m heree,,,,");
        JSONObject js = new JSONObject();

        try {
            js.put("id", "80");
            js.put("distributerId", "1");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        final RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"), (js.toString()));
        // Dialog start
        RetrofitApiClient.get().getAppVersion(body).enqueue(new Callback<AppVersionResponse>() {
            @Override
            public void onResponse(Call<AppVersionResponse> call, Response<AppVersionResponse> response) {
                // dialog End
                Log.e("my Response  : ", response.body().toString());
                Log.e("my Response  : ", "Rajesh  :  " + new Gson().toJson(response));

                Log.e("my Response  : ", response.body().getMessage().toString());
                ListData = response.body().getList();

                Log.e("Total Legnth", "  :  " + ListData.size());
            }


            @Override
            public void onFailure(Call<AppVersionResponse> call, Throwable t) {
                Log.e("my Response  : ", t.toString());
            }
        });


    }


    @Override
    public void onBackPressed() {
        finish();
    }


    private void Logintask(String user_name, String password, String device_id, String emi_id, String fcmID) {


    }


    private void createids() {
        btn_login = (Button) findViewById(R.id.btn_signin);
        edt_user_name = (EditText) findViewById(R.id.edt_user_name);
        edt_password = (EditText) findViewById(R.id.edt_password);


    }

}
