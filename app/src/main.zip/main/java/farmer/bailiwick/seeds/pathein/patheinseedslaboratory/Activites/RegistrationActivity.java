package farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Activites;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;
import com.whiteelephant.monthpicker.MonthPickerDialog;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.R;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Support.RootActivity;

/**
 * Created by Prince on 12-11-2018.
 */

public class RegistrationActivity extends RootActivity implements DatePickerDialog.OnDateSetListener {
    Context mContext;

    LinearLayout lnt_issue_date, lnt_date_receipt,lnt_year_of_production;
    TextView txt_issue_date, txt_date_receipt,txt_year_of_production;
    Spinner spnr_crop,spnr_varity,spnr_region,spnr_season;

    Shimmer shimmer;
    ShimmerTextView txt_header;

    DatePickerDialog datePickerDialog;

    ArrayList<String> LIST_crop_name,LIST_varity_name,LIST_region_name,LIST_season_name;
    ArrayAdapter Spinner_Crop_adapter,Spinner_varity_adapter,Spinner_region_adapter,Spinner_Season_adapter;

    enum DateType {DR, DI}

    final Calendar c = Calendar.getInstance();
    int year = c.get(Calendar.YEAR);
    int month = c.get(Calendar.MONTH);
    int day = c.get(Calendar.DAY_OF_MONTH);
    DateType DT;

    public static boolean isDateValid(String date) {
        final String DATE_FORMAT = "dd-MM-yyyy";
        try {
            DateFormat df = new SimpleDateFormat(DATE_FORMAT);
            df.setLenient(false);
            df.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);
        mContext = RegistrationActivity.this;

        createIDS();
        setSpinnerData();
        clickevent();
    }

    private void setSpinnerData() {
        setCropData();
        setVerity_data();
        setregion_Data();
        setSeason_Data();

    }

    private void setSeason_Data() {
        LIST_season_name = new ArrayList<>();
        LIST_season_name.add("Select Season");
        LIST_season_name.add("Varity A");
        LIST_season_name.add("Varity B");
        LIST_season_name.add("Varity C");
        LIST_season_name.add("Varity D");

        Spinner_Season_adapter = new ArrayAdapter<String>(mContext, R.layout.spinner_layout_white_text, LIST_season_name);
//        Spinner_Religion_adapter.setDropDownViewResource(R.layout.spinner_layout);
        Spinner_Season_adapter.setDropDownViewResource(R.layout.spinner_layout_white);

        spnr_season.setAdapter(Spinner_Season_adapter);

    }

    private void setVerity_data() {

        LIST_varity_name = new ArrayList<>();
        LIST_varity_name.add("Select Varity");
        LIST_varity_name.add("Varity A");
        LIST_varity_name.add("Varity B");
        LIST_varity_name.add("Varity C");
        LIST_varity_name.add("Varity D");

        Spinner_varity_adapter = new ArrayAdapter<String>(mContext, R.layout.spinner_layout_white_text, LIST_varity_name);
//        Spinner_Religion_adapter.setDropDownViewResource(R.layout.spinner_layout);
        Spinner_varity_adapter.setDropDownViewResource(R.layout.spinner_layout_white);

        spnr_varity.setAdapter(Spinner_varity_adapter);
    }

    private void setregion_Data () {
      LIST_region_name = new ArrayList<>();
        LIST_region_name.add("Select Region");
        LIST_region_name.add("Region A");
        LIST_region_name.add("Region B");
        LIST_region_name.add("Region C");
        LIST_region_name.add("Region D");

        Spinner_region_adapter = new ArrayAdapter<String>(mContext, R.layout.spinner_layout_white_text, LIST_region_name);
//        Spinner_Religion_adapter.setDropDownViewResource(R.layout.spinner_layout);
        Spinner_region_adapter.setDropDownViewResource(R.layout.spinner_layout_white);

        spnr_region.setAdapter(Spinner_region_adapter);
    }

    private void setCropData() {
        LIST_crop_name = new ArrayList<>();
        LIST_crop_name.add("Select Crop");
        LIST_crop_name.add("Crop A");
        LIST_crop_name.add("Crop B");
        LIST_crop_name.add("Crop C");
        LIST_crop_name.add("Crop D");

        Spinner_Crop_adapter = new ArrayAdapter<String>(mContext, R.layout.spinner_layout_white_text, LIST_crop_name);
//        Spinner_Religion_adapter.setDropDownViewResource(R.layout.spinner_layout);
        Spinner_Crop_adapter.setDropDownViewResource(R.layout.spinner_layout_white);

        spnr_crop.setAdapter(Spinner_Crop_adapter);
    }

    private void clickevent() {
        lnt_year_of_production.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MonthPickerDialog.Builder builder = new MonthPickerDialog.Builder(mContext, new MonthPickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(int selectedMonth, int selectedYear) {
                        txt_year_of_production.setText(Integer.toString(selectedYear));
                        year = selectedYear;
                    }
                }, year, 0);

                builder.showYearOnly()
                        .setYearRange(1990, 2030)
                        .build()
                        .show();
            }

        });
        lnt_issue_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DT = DateType.DI;
                datePickerDialog.show();

            }
        });
        lnt_date_receipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DT = DateType.DR;
                datePickerDialog.show();
            }
        });
    }

    private void createIDS() {
        datePickerDialog = new DatePickerDialog(this, this, year, month, day);
        txt_header = (ShimmerTextView) findViewById(R.id.txt_header);

        lnt_issue_date = (LinearLayout) findViewById(R.id.lnt_issue_date);
        lnt_date_receipt = (LinearLayout) findViewById(R.id.lnt_date_receipt);
        lnt_year_of_production= (LinearLayout) findViewById(R.id.lnt_year_of_production);

        txt_issue_date = (TextView) findViewById(R.id.txt_issue_date);
        txt_date_receipt = (TextView) findViewById(R.id.txt_date_receipt);
        txt_year_of_production= (TextView) findViewById(R.id.txt_year_of_production);

        spnr_crop = (Spinner) findViewById(R.id.spnr_crop);
        spnr_varity = (Spinner) findViewById(R.id.spnr_varity);
        spnr_region = (Spinner) findViewById(R.id.spnr_region);
        spnr_season = (Spinner) findViewById(R.id.spnr_season);

        txt_issue_date.setText(day + " - " + (month+1) + " - " + year);
        shimmer = new Shimmer();
        shimmer.start(txt_header);
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String month1 = "", day1 = "";
        if (String.valueOf(month + 1).length() == 1) month1 = "0" + (month + 1);
        else month1 = (month + 1) + "";
        if (String.valueOf(day).length() == 1) day1 = "0" + (day);
        else day1 = (day) + "";
        if (DT == DateType.DR) {
            txt_date_receipt.setText(day1 + " - " + month1 + " - " + year);

        } else if (DT == DateType.DI) {
            txt_issue_date.setText(day1 + " - " + month1 + " - " + year);

        }
    }
}
