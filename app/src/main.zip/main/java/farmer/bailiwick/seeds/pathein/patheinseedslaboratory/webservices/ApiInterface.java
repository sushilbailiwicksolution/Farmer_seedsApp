package farmer.bailiwick.seeds.pathein.patheinseedslaboratory.webservices;

import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Model.AppVersionResponse;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiInterface {

    @POST("getAppVersion")
    Call<AppVersionResponse> getAppVersion(@Body RequestBody body);

/*
    @FormUrlEncoded
    @POST("admin-ajax.php")
    Call<SyllabusResponse> getSyllabusDetails(@FieldMap(encoded = true) Map<String, String> fields);
*/


}
