package farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Activites;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;

import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.R;
import farmer.bailiwick.seeds.pathein.patheinseedslaboratory.Support.RootActivity;

/**
 * Created by Prince on 06-11-2018.
 */

public class DashBoardActivity extends RootActivity {
    Shimmer shimmer;
    ShimmerTextView txt_header;
    CardView crd_registration;
    Context mContext;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);
        mContext = DashBoardActivity.this;

        createIDS();
        shimmer = new Shimmer();
        shimmer.start(txt_header);
        clickEvent();

    }

    private void clickEvent() {
        crd_registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext,RegistrationActivity.class);
                startActivity(i);
            }
        });
    }

    private void createIDS() {
        txt_header = (ShimmerTextView) findViewById(R.id.txt_header);
        crd_registration = (CardView) findViewById(R.id.crd_registration);
    }
}
